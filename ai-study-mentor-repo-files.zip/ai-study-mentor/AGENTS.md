# Hướng dẫn cho AI Code (AI Study Mentor)

Trước khi sinh bất kỳ code nào, hãy đọc và tuân thủ tuyệt đối:

1. `docs/FE_BE_COMMON_RULES.md` (nguyên tắc chung FE/BE, đã chốt)
2. `docs/api/openapi.yaml` (hợp đồng API, nguồn sự thật duy nhất)

Không tự đổi công nghệ, endpoint, field, enum, mã lỗi. Nếu yêu cầu mâu thuẫn hoặc thiếu thông tin,
hãy nói rõ và hỏi lại. Không ghi secret vào code.
(Có thể đổi tên/sao chép file này thành `CLAUDE.md` hoặc file rules của công cụ bạn dùng.)
