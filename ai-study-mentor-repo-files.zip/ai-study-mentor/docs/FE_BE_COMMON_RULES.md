# BẢN NGUYÊN TẮC CHUNG CHO 2 TEAM FE VÀ BE — AI STUDY MENTOR

> **Phiên bản:** 1.0 (đã chốt, xem Mục 15). Thay đổi quy tắc phải qua PR và được cả FE lẫn BE owner approve.
> **Căn cứ:** Technical SPEC v2 + Product Backlog Sprint 0–6 (14 tuần, Agile/Scrum)
> **Dự án:** BrightPath Learning — BTEC HND L5, Unit 22

---

## 0. HƯỚNG DẪN CHO AI CODE (ĐỌC TRƯỚC KHI LÀM BẤT CỨ ĐIỀU GÌ)

Bạn là AI hỗ trợ lập trình cho một thành viên của nhóm 4 người (junior). File này là **hợp đồng chung** giữa team FE (Android) và team BE (Spring Boot). Khi sinh code:

1. **Tuân thủ tuyệt đối file này.** Không tự đổi công nghệ, tên endpoint, tên field, enum, mã lỗi.
2. Nếu yêu cầu của người dùng **mâu thuẫn** với file này, hãy nói rõ chỗ mâu thuẫn và hỏi lại, không tự chọn.
3. Nếu file này **chưa quy định** điều cần thiết, hãy ghi rõ "Chưa được quy định trong Bản nguyên tắc chung" và đề xuất, không tự coi là đã chốt.
4. Mọi thay đổi API/schema phải đi theo quy trình ở **Mục 12**.
5. Không bao giờ ghi API key, mật khẩu, JWT secret, file service account vào source code.
6. Code phải dễ đọc, đặt tên rõ nghĩa, có xử lý lỗi và validate đầu vào. Ưu tiên đơn giản hơn "thông minh".
7. Ghi chú, giải thích bằng tiếng Việt; code, tên class/hàm/biến/endpoint bằng tiếng Anh.

---

## 1. CÔNG NGHỆ CỐ ĐỊNH (theo SPEC v2 — KHÔNG ĐƯỢC ĐỔI)

| Tầng | Công nghệ |
|---|---|
| Android | Kotlin, Android Studio, Jetpack Compose, MVVM, StateFlow, Repository, Retrofit + OkHttp, Coroutines + Flow, Room, Hilt, Coil, CameraX, FCM SDK |
| Backend | Java, Spring Boot, Spring Security (JWT), Spring Data JPA, REST/JSON |
| Dữ liệu | MySQL (dữ liệu chính), Redis (cache + chống trùng câu hỏi + rate limit) |
| AI | Gemini 1.5 Flash hoặc GPT-4o-mini, **chỉ được gọi từ backend** qua AI Orchestrator |
| Firebase | Chỉ **Storage** (ảnh bài tập) và **FCM** (push). Không dùng Firestore/Firebase Auth làm backend |
| Cấm | Flutter, gọi AI trực tiếp từ Android, XML Views (trừ khi bắt buộc), thêm kiến trúc/thư viện lớn khi chưa họp nhóm |

Phiên bản cụ thể (Java, Spring Boot, Gradle/Maven, minSdk…): xem Mục 15, quyết định D1.

---

## 2. CẤU TRÚC REPO (MONOREPO)

```text
/android      ← Kotlin + Compose
/backend      ← Spring Boot
/docs         ← api/openapi.yaml, ERD, test plan, DEPLOY.md
/deploy       ← docker-compose.yml, Caddyfile, .env.example
/.github      ← workflows, CODEOWNERS, pull_request_template.md
```

- `docs/api/openapi.yaml` là **nguồn sự thật duy nhất** của API. FE và BE đều đọc từ đây.
- Package gốc: `com.brightpath.studymentor` (cả Android và Backend).

### Cấu trúc Android
```text
com.brightpath.studymentor
├── data
│   ├── remote    (Retrofit API interfaces, DTO)
│   ├── local     (Room: entity, dao, database)
│   └── repository
├── domain        (model dùng trong UI)
├── di            (Hilt modules)
└── ui
    └── <feature> (Screen, ViewModel, UiState)
```
Luồng: `Composable → ViewModel → Repository → (RemoteDataSource | Room)`. **Composable không được gọi API/DB trực tiếp.**

### Cấu trúc Backend
```text
com.brightpath.studymentor
├── controller   (chỉ nhận request, validate, trả response)
├── service      (business logic)
├── repository   (Spring Data JPA)
├── entity
├── dto          (request/response)
├── ai           (AI Orchestrator: PromptHandler, SafetyFilter, TokenLimiter, AiClient, CacheService)
├── security     (JWT, filter, config)
├── exception    (GlobalExceptionHandler, ErrorCode)
└── config
```
Controller không chứa query DB, không gọi AI trực tiếp.

---

## 3. QUY ƯỚC API CHUNG

| Hạng mục | Quy ước |
|---|---|
| Base path | `/api/...` (không có version trong MVP) |
| Auth | Header `Authorization: Bearer <accessToken>`; chỉ `/api/auth/register`, `/api/auth/login`, `/api/health` là công khai |
| ID | UUID dạng chuỗi 36 ký tự (khớp `VARCHAR(36)` trong SPEC) |
| Thời gian | ISO-8601 UTC, ví dụ `2026-10-10T08:30:00Z`. Server và DB chạy UTC; FE tự đổi sang giờ máy |
| JSON | `camelCase` cho field; enum là `UPPER_SNAKE_CASE` (chuỗi) |
| Null | Field không có giá trị thì **bỏ qua hoặc trả `null`**; FE phải chịu được cả hai, DTO Kotlin để nullable |
| Phân trang | Query `?page=0&size=20`; response `{ "content": [...], "page": 0, "size": 20, "totalPages": 3, "totalElements": 54 }` |
| Content-Type | `application/json; charset=utf-8` |
| Mã HTTP | 200 OK, 201 Created, 204 No Content, 400 validate, 401 chưa đăng nhập/token hết hạn, 403 không có quyền, 404, 409 trùng, 413 file quá lớn, 429 rate limit, 500 lỗi server, 502/504 lỗi AI |

### Định dạng lỗi (mọi lỗi đều dùng đúng khuôn này)
```json
{
  "timestamp": "2026-10-10T08:30:00Z",
  "status": 401,
  "errorCode": "TOKEN_EXPIRED",
  "message": "Phiên đăng nhập đã hết hạn.",
  "fieldErrors": [ { "field": "email", "message": "Email không hợp lệ" } ]
}
```
- `fieldErrors` chỉ có khi lỗi validate (400).
- **FE dựa vào `errorCode` để hiển thị thông báo, không dựa vào `message`.**
- BE tuyệt đối không trả stack trace, tên bảng, hay thông tin nhạy cảm.

### Bảng `errorCode` (thêm mã mới phải theo Mục 12)

| errorCode | HTTP | Ý nghĩa | FE xử lý |
|---|---|---|---|
| `VALIDATION_ERROR` | 400 | Dữ liệu sai định dạng | Hiển thị lỗi cạnh field |
| `WEAK_PASSWORD` | 400 | Mật khẩu yếu | Hiện gợi ý quy tắc mật khẩu |
| `INVALID_CREDENTIALS` | 401 | Sai email hoặc mật khẩu (không nói cái nào sai) | Thông báo chung |
| `TOKEN_EXPIRED` | 401 | Access token hết hạn | Tự gọi `/api/auth/refresh` một lần rồi gọi lại request ban đầu (xem Mục 7) |
| `UNAUTHORIZED` | 401 | Thiếu/sai access token | Xoá token, về màn hình đăng nhập |
| `REFRESH_TOKEN_INVALID` | 401 | Refresh token sai, hết hạn hoặc đã bị thu hồi | Xoá token, về màn hình đăng nhập |
| `CONSENT_TOKEN_INVALID` | 400 | Mã/liên kết đồng ý của phụ huynh sai hoặc hết hạn | Thông báo, cho yêu cầu gửi lại |
| `ACCOUNT_PENDING_CONSENT` | 403 | Tài khoản dưới 13 tuổi chưa có đồng ý phụ huynh | Màn hình chờ đồng ý |
| `EMAIL_ALREADY_EXISTS` | 409 | Email đã đăng ký | Thông báo |
| `NOT_FOUND` | 404 | Không tìm thấy tài nguyên | Thông báo |
| `INVALID_IMAGE` | 400 | Ảnh sai định dạng/quá lớn | Yêu cầu chọn ảnh khác |
| `CONTENT_NOT_ALLOWED` | 422 | Nội dung bị Safety Filter chặn / ngoài phạm vi học tập | Thông báo thân thiện |
| `RATE_LIMITED` | 429 | Gửi quá nhiều (kèm header `Retry-After`) | Hiện thời gian chờ |
| `AI_TIMEOUT` | 504 | AI quá thời gian | Nút "Thử lại" |
| `AI_PROVIDER_ERROR` | 502 | AI lỗi/trả sai định dạng | Nút "Thử lại" |
| `INTERNAL_ERROR` | 500 | Lỗi không xác định | Thông báo chung |

---

## 4. ENUM DÙNG CHUNG

```text
EducationLevel : MIDDLE_SCHOOL | HIGH_SCHOOL | UNIVERSITY
PreferredStyle : SHORT | DETAILED | STEP_BY_STEP
QuestionType   : TEXT | IMAGE
Subject        : MATHEMATICS | SCIENCE | PROGRAMMING | HISTORY | LANGUAGES | OTHER
Difficulty     : EASY | MEDIUM | HARD
AccountStatus  : ACTIVE | PENDING_PARENTAL_CONSENT
QuizType       : MCQ | SHORT_ANSWER | FILL_BLANK
```
BE trả enum nào thì FE phải có enum đó; FE gặp giá trị lạ thì rơi về `OTHER`/mặc định, **không được crash**.

---

## 5. HỢP ĐỒNG API THEO SPRINT

> Chi tiết request/response đầy đủ nằm trong `docs/api/openapi.yaml` (hiện có Sprint 1–2; Sprint 3–6 sẽ được bổ sung đầu mỗi sprint). Bảng dưới là danh mục tên endpoint đã thống nhất.

### Sprint 1 — Auth & Onboarding
| Endpoint | Auth | Ghi chú |
|---|---|---|
| `POST /api/auth/register` | Không | Body: `email, password, displayName, dateOfBirth`, `parentEmail?` (bắt buộc nếu < 13 tuổi). Response 201: `{ userId, accountStatus }` |
| `POST /api/auth/parental-consent/confirm` | Không | Body `{ consentToken }` (lấy từ email gửi phụ huynh). Thành công → tài khoản `ACTIVE` |
| `POST /api/auth/login` | Không | Response: `{ accessToken, refreshToken, expiresIn, user: { userId, email, displayName, accountStatus, onboardingCompleted } }`. Tài khoản chờ đồng ý → 403 `ACCOUNT_PENDING_CONSENT` |
| `POST /api/auth/refresh` | Không | Body `{ refreshToken }` → cặp token mới (xoay vòng, token cũ vô hiệu) |
| `POST /api/auth/logout` | Không | Body `{ refreshToken }` → 204, thu hồi refresh token |
| `PUT /api/profile/onboarding` | Có | Body: `educationLevel, subjects[], preferredStyle` |
| `GET /api/profile` | Có | Hồ sơ hiện tại (gồm XP, level) |
| `GET /api/health` | Không | Dùng cho healthcheck/smoke test |

Quy tắc mật khẩu (FE kiểm tra inline, BE kiểm tra quyết định): ≥ 8 ký tự, có chữ hoa, chữ thường và số.

Token: access token sống **30 phút**, refresh token sống **14 ngày** và **xoay vòng** mỗi lần refresh. Nếu một refresh token đã bị thay thế mà bị dùng lại, BE thu hồi toàn bộ refresh token của người dùng đó.

### Sprint 2 — Câu hỏi text & AI
`POST /api/questions` (Có)
```json
// Request
{ "questionType": "TEXT", "contentText": "Giải 2x + 5 = 15" }
// Response 201 (AnswerResponse)
{
  "questionId": "uuid", "answerId": "uuid",
  "subject": "MATHEMATICS", "difficulty": "EASY",
  "steps": [ { "title": "Chuyển vế", "content": "2x = 15 - 5", "formula": "2x = 10" } ],
  "finalAnswer": "x = 5",
  "cacheHit": false,
  "createdAt": "2026-10-10T08:30:00Z"
}
```
- DB lưu `steps` dưới dạng chuỗi JSON trong cột `answers.step_by_step` (TEXT). Định dạng `steps` xem D5.
- BE giới hạn `contentText` ≤ 2000 ký tự.
- FE đặt timeout OkHttp ≈ 30s và hiện loading; NFR-01 (< 3.5s) là mục tiêu của BE chứ không phải timeout của FE.
- BE cung cấp **mock response cố định** (endpoint hoặc profile `mock`) để FE làm UI không phải chờ AI.

### Sprint 3 — Ảnh, lịch sử, bookmark
| Endpoint | Ghi chú |
|---|---|
| `POST /api/uploads/image-url` | Trả `{ uploadUrl, objectPath }` (signed URL để FE upload thẳng lên Firebase Storage, xem D8) |
| `POST /api/questions` | `{ "questionType": "IMAGE", "imagePath": "...", "contentText"?: "..." }` |
| `GET /api/questions?page&size&subject&q&updatedSince` | Lịch sử + tìm kiếm + dùng cho sync Room |
| `GET /api/questions/{id}` | Chi tiết câu hỏi + đáp án |
| `POST /api/bookmarks` | `{ "questionId" }` → 201 |
| `DELETE /api/bookmarks/{questionId}` | → 204 |
| `GET /api/bookmarks?page&size` | |

- Đường dẫn Storage: `homework/{userId}/{uuid}.jpg`. Chỉ nhận JPEG/PNG; **FE nén ≤ 2MB** trước khi upload.
- Room: khoá chính entity là `questionId` (UUID từ server). Khi xung đột, **server thắng**.

### Sprint 4 — Quiz & Dashboard
| Endpoint | Ghi chú |
|---|---|
| `POST /api/quizzes` | Body `{ "topic"?, "subject", "quizType"?, "count": 5 }` → quiz + danh sách câu (**không** chứa đáp án đúng) |
| `POST /api/quizzes/{quizId}/attempts` | Body `{ "answers": [ { "quizQuestionId", "answer" } ] }` → `{ score, results: [ { quizQuestionId, correct, explanation, correctAnswer } ] }`. **BE chấm điểm** |
| `GET /api/dashboard` | `{ totalQuestions, topSubjects[], quizAccuracy, reviewTimeMinutes, insights[] }` |

### Sprint 5 — Gamification & Notification
| Endpoint | Ghi chú |
|---|---|
| `GET /api/leaderboard?scope=GLOBAL&limit=50` | `{ entries: [ { rank, displayName, totalXp, level } ], me: { rank, ... } }` |
| `GET /api/badges` | Tất cả badge + trạng thái đã đạt |
| `POST /api/devices` | Đăng ký FCM token: `{ "fcmToken" }` |
| `DELETE /api/devices/{fcmToken}` | Khi đăng xuất |

- **BE là nơi duy nhất tính XP/level/badge.** FE chỉ hiển thị.
- Mọi API có thể cộng XP trả thêm khối: `"gamification": { "xpAwarded": 10, "totalXp": 120, "level": 2, "leveledUp": false, "newBadges": [ ] }`.
- FCM `data` payload: `{ "type": "REVIEW_REMINDER|MISTAKE_ALERT|SUMMARY|MOTIVATION", "targetScreen": "bookmarks|question_detail|dashboard", "targetId": "uuid?" }`. Notification channel id: `study_mentor_default`.

### Sprint 6 — Hardening
| Endpoint | Ghi chú |
|---|---|
| `POST /api/answers/{answerId}/report` | `{ "reason", "note"? }` → 201 |
| `DELETE /api/users/me` | Xoá/ẩn danh dữ liệu (GDPR). FE: màn hình xác nhận → đăng xuất ngay |
| Rate limit | Vượt giới hạn → 429 + `RATE_LIMITED` + `Retry-After` |

**Đóng băng contract sau tuần 13:** chỉ sửa lỗi, không thêm/đổi field.

---

## 6. LUỒNG AI (BACKEND)

Thứ tự cố định trong `QuestionService` / AI Orchestrator:

```text
1. Validate input (độ dài, ảnh hợp lệ)
2. Input Safety Filter
3. Rate limit / Token Limiter
4. Kiểm tra Redis (cache hit → trả ngay, cacheHit=true)
5. (Nếu IMAGE) lấy ảnh từ Firebase Storage
6. PromptHandler dựng prompt (theo môn + cấp học + PreferredStyle + guardrail)
7. Gọi AI provider (timeout cấu hình được)
8. Parse JSON trả về → nếu sai định dạng: AI_PROVIDER_ERROR
9. Output Safety Filter
10. Lưu MySQL (questions, answers: token_used, cache_hit) → lưu Redis
11. Cộng XP, cập nhật thống kê
12. Trả AnswerResponse
```
- Tên model và API key đọc từ biến môi trường/config (`AI_PROVIDER`, `AI_MODEL`, `AI_API_KEY`), **không hard-code**.
- AI phải được yêu cầu trả **JSON đúng schema** `{subject, difficulty, steps[], finalAnswer}`; BE luôn kiểm tra trước khi tin.
- **Khoá cache (D9):** `qa:v1:{sha256hex}`, trong đó chuỗi đầu vào là `normalizedText + "|" + educationLevel + "|" + preferredStyle`. Chuẩn hoá = Unicode NFC, `trim`, chữ thường, gộp mọi khoảng trắng liên tiếp thành một dấu cách; **không** bỏ dấu tiếng Việt (bỏ dấu có thể đổi nghĩa câu hỏi). Không đưa `userId` vào khoá để người dùng cùng cấp học dùng chung đáp án. Môn học không nằm trong khoá vì chỉ biết sau khi AI trả lời. TTL cấu hình bằng `CACHE_TTL_DAYS` (mặc định 30). Câu hỏi dạng IMAGE: cách tạo khoá chốt ở Sprint 3. Tiền tố `v1` để đổi cách chuẩn hoá về sau mà không dùng nhầm cache cũ.
- Lỗi Redis không được làm hỏng request (bỏ qua cache và gọi AI).

---

## 7. QUY TẮC CHO TEAM FE (ANDROID)

1. Mỗi màn hình có `XxxScreen` (Composable), `XxxViewModel`, `XxxUiState` (data class / sealed interface).
2. ViewModel xuất `StateFlow<UiState>`; Composable dùng `collectAsStateWithLifecycle()`.
3. `UiState` luôn có trạng thái **Loading / Success / Error / Empty** (nếu áp dụng).
4. Mọi lời gọi API trả về `Result` (hoặc sealed class) đã map `errorCode` → thông báo tiếng Việt; **không** để exception lọt lên UI.
5. `BASE_URL` đặt theo build variant bằng `buildConfigField` (debug dùng `http://10.0.2.2:8080`, staging/release dùng HTTPS). Không hard-code URL trong code.
6. Access token và refresh token lưu bằng `EncryptedSharedPreferences` (hoặc DataStore mã hoá), **không** lưu plain text. Một OkHttp Interceptor gắn header `Authorization`; một `Authenticator` xử lý 401 `TOKEN_EXPIRED`: gọi `/api/auth/refresh` **một lần** (dùng khoá/mutex để nhiều request song song chỉ refresh một lần), lưu cặp token mới rồi gọi lại request. Nếu refresh trả `REFRESH_TOKEN_INVALID` thì xoá token và điều hướng về Login. Không được lặp vô hạn việc refresh. Khi đăng xuất, gọi `/api/auth/logout` rồi xoá token cục bộ.
7. Chuỗi hiển thị đặt trong `strings.xml`, không viết cứng trong Composable.
8. Cuộn/bố cục hỗ trợ màn hình nhỏ; màu và font dùng `MaterialTheme`, không hard-code màu trong từng màn hình.
9. DTO (data/remote) tách riêng với model UI (domain); có hàm mapper.
10. Ảnh: CameraX chụp, Coil hiển thị, nén ≤ 2MB trước khi upload.
11. Đặt tên: `QuestionRepository`, `QuestionApi`, `QuestionDao`, `QuestionEntity`, `QuestionDto`.
12. Khi BE chưa sẵn sàng, FE dùng `FakeXxxRepository` hoặc mock server dựa trên `openapi.yaml`, rồi đổi sang repository thật qua Hilt.

## 8. QUY TẮC CHO TEAM BE (SPRING BOOT)

1. Controller → Service → Repository. DTO tách khỏi Entity; không trả Entity ra ngoài.
2. Validate bằng Bean Validation (`@Valid`, `@NotBlank`, `@Size`…).
3. Mọi exception đi qua `@RestControllerAdvice` (`GlobalExceptionHandler`) và trả đúng khuôn lỗi ở Mục 3.
4. Mật khẩu băm bằng BCrypt. Trường nhạy cảm theo SPEC (AES-256 at rest): danh sách trường xem D12.
5. Thay đổi schema **chỉ qua migration** (Flyway), không dùng `ddl-auto=update` trên staging/production.
6. Không log mật khẩu, JWT, API key, nội dung cá nhân nhạy cảm.
7. Cấu hình bằng biến môi trường; có `application-local.yml` (không commit) và `.env.example` (commit, không có giá trị thật).
8. Có Swagger UI/springdoc để xuất `openapi.yaml`.
9. Viết unit test cho Service (đặc biệt: XP, chấm quiz, parse AI, cache); integration test dùng Testcontainers hoặc service container MySQL/Redis.
10. Endpoint luôn kiểm tra quyền sở hữu: người dùng chỉ truy cập dữ liệu của chính mình.
11. Refresh token là chuỗi ngẫu nhiên khó đoán; DB chỉ lưu **bản băm** (SHA-256), không lưu bản gốc. Xoay vòng mỗi lần refresh, phát hiện dùng lại token cũ thì thu hồi cả nhóm. JWT secret và thời hạn token đọc từ config.

---

## 9. THAY ĐỔI SCHEMA SO VỚI SPEC v2 (ĐỀ XUẤT — CHƯA PHẢI SPEC)

Các story yêu cầu dữ liệu mà schema SPEC v2 chưa có. Đề xuất thêm (đã chốt ở D4):

| Thay đổi | Lý do |
|---|---|
| `users`: thêm `display_name`, `date_of_birth`, `parent_email`, `account_status` | US-03 COPPA, leaderboard |
| Bảng `refresh_tokens (token_id, user_id, token_hash, expires_at, revoked, replaced_by, created_at)` | Refresh token có xoay vòng và thu hồi |
| Bảng `parental_consents (consent_id, user_id, token_hash, expires_at, confirmed_at)` | US-03: xác nhận của phụ huynh |
| Bảng `student_subjects (profile_id, subject)` | US-04 chọn môn quan tâm |
| `questions`: thêm `difficulty`; chỉ mục trên `(profile_id, created_at)` | Lịch sử/tìm kiếm |
| Bảng `quiz_questions` và `quiz_attempt_answers` | US-23/24: lưu câu hỏi, đáp án, kết quả từng câu |
| Bảng `badges`, `user_badges` | US-34 |
| Bảng `device_tokens (profile_id, fcm_token)` | US-36/37 FCM |
| Bảng `answer_reports` | US-39 |
| Bảng `xp_events` (tuỳ chọn) | Truy vết cộng XP, hỗ trợ test |

Mọi thay đổi đi kèm file migration Flyway và cập nhật ERD trong `/docs`.

---

## 10. QUY TRÌNH GIT

### Nhánh
| Nhánh | Quy tắc |
|---|---|
| `main` | Luôn chạy được. Cấm push trực tiếp. Chỉ nhận PR từ `develop` cuối sprint, gắn tag `v0.N.0` (bản cuối `v1.0.0`) |
| `develop` | Nhánh tích hợp. Cấm push trực tiếp. Chỉ nhận PR |
| `feature/US-xx-mo-ta-ngan-android` / `-backend` | Mỗi user story một nhánh cho mỗi phía, tách từ `develop`, sống ≤ 3 ngày |
| `bugfix/<mo-ta>` | Sửa lỗi trên `develop` |
| `hotfix/<mo-ta>` | Sửa gấp trên `main`, sau đó merge ngược về `develop` |

Commit: `feat(US-10): add question endpoint`, `fix(US-16): ...`, `docs: ...`, `test: ...`, `chore: ...`.

### Pull Request & approval
- `develop`: bắt buộc PR, **1 approval**, CI xanh, resolve hết comment, **Squash merge**, bật dismiss stale approvals.
- `main`: như trên nhưng **2 approvals**.
- Người tạo PR không tự approve. Ưu tiên review chéo (FE review BE về contract; QA review phần test).
- `CODEOWNERS`: `/docs/api/openapi.yaml` yêu cầu cả owner FE và BE approve; `/.github/` và `/deploy/` do Member D.
- PR template: story ID, có đổi API không, đã cập nhật OpenAPI, đã chạy test, ảnh chụp màn hình (FE), không có secret.
- **PR đụng tới `openapi.yaml` hoặc migration phải được báo trong kênh chat của nhóm.**

### Cập nhật nhánh
Trước khi tạo PR: `git fetch && git rebase origin/develop` (hoặc merge `develop` vào nhánh mình), chạy test, rồi push.

---

## 11. BẢO MẬT (ÁP DỤNG CHO CẢ HAI TEAM)

- Không commit: `.env`, `application-local.yml`, `*.jks`/keystore, `google-services.json` của môi trường production, file service account Firebase Admin. Nếu lỡ commit secret → **đổi secret ngay**, không chỉ xoá file.
- Android không chứa AI key và không gọi AI. Refresh token không được ghi vào log.
- TLS cho staging/production. Android release không bật cleartext.
- Storage Rules: người dùng chỉ ghi vào thư mục của mình; ảnh không công khai.
- COPPA: dưới 13 tuổi chỉ kích hoạt tài khoản sau khi phụ huynh đồng ý; không thu thập dữ liệu thừa.
- Xoá tài khoản (`DELETE /api/users/me`) phải xoá/ẩn danh dữ liệu cá nhân và ảnh trên Storage.

---

## 12. QUY TRÌNH THAY ĐỔI CONTRACT

Áp dụng khi cần thêm/sửa endpoint, field, enum, `errorCode`, schema:

1. Người cần đổi tạo PR **chỉ sửa `docs/api/openapi.yaml` (và/hoặc migration)**, nêu lý do.
2. Cả FE owner và BE owner approve.
3. Merge vào `develop`, báo cả nhóm.
4. Sau đó mới code FE/BE theo contract mới.
5. Thay đổi phá vỡ (đổi tên/xoá field) phải có người phụ trách cả hai phía cùng cập nhật trong cùng sprint.

Quy tắc tương thích: **thêm field mới là được; xoá/đổi tên/đổi kiểu field là thay đổi phá vỡ.**

---

## 13. MÔI TRƯỜNG VÀ TRIỂN KHAI

| Môi trường | Mục đích |
|---|---|
| Local | Mỗi người chạy bằng `docker compose` (MySQL + Redis) và backend/emulator |
| Staging | Tự động deploy từ `develop` (hoặc deploy tay cuối mỗi sprint), dùng cho Sprint Review |
| Production/Demo | Deploy từ tag trên `main` |

- Backend đóng gói bằng Docker; `docker-compose.yml` gồm `backend`, `mysql`, `redis`, cộng reverse proxy (Caddy/Nginx) lo HTTPS. Firebase là dịch vụ ngoài.
- Build Android: `debug` trỏ local/staging, `release` trỏ production; APK demo build từ đúng tag.
- MySQL dùng `utf8mb4`, múi giờ UTC.
- Mỗi lần deploy chạy **smoke test**: health → đăng ký → đăng nhập → gửi câu hỏi → gửi lại (kiểm tra `cacheHit=true`).
- Staging phải chạy được từ **Sprint 1**. Cuối Sprint 5 làm "release rehearsal" từ môi trường sạch.
- Tuần 13–14: code freeze, chỉ nhận bugfix.
- Người phụ trách deploy: xem D13.

---

## 14. ĐỊNH NGHĨA HOÀN THÀNH (DoD) CHO MỘT STORY

- [ ] Code theo đúng contract/quy tắc ở file này
- [ ] Có unit test cho logic chính; CI xanh
- [ ] `openapi.yaml` đã cập nhật nếu có đổi API
- [ ] Không có secret, không có `TODO` quan trọng bỏ lửng
- [ ] Đã chạy thử với staging hoặc mock theo contract
- [ ] PR đã được approve và merge vào `develop`
- [ ] Ticket Jira đã chuyển sang Done

---

## 15. CÁC QUYẾT ĐỊNH ĐÃ CHỐT

| # | Vấn đề | Quyết định |
|---|---|---|
| D1 | Phiên bản & build tool | Java 17, Spring Boot 3.x, Maven; Android minSdk 26, Gradle Kotlin DSL |
| D2 | Package name | `com.brightpath.studymentor` |
| D3 | Refresh token | **Có.** Access token 30 phút, refresh token 14 ngày, xoay vòng, lưu băm trong DB |
| D4 | Thay đổi schema Mục 9 | Chấp nhận, thực hiện bằng Flyway migration |
| D5 | Định dạng `steps` | Mảng JSON `{title, content, formula?}` |
| D6 | Quy tắc mật khẩu | ≥ 8 ký tự, có chữ hoa, chữ thường, số |
| D7 | Phụ huynh đồng ý (COPPA) | Email chứa mã/liên kết gửi tới `parentEmail`, xác nhận qua `/api/auth/parental-consent/confirm` |
| D8 | Upload ảnh | BE cấp signed upload URL, FE upload thẳng lên Firebase Storage |
| D9 | Khoá cache Redis | **Hash SHA-256 của câu hỏi đã chuẩn hoá** + cấp học + phong cách giải thích (chi tiết ở Mục 6); semantic similarity để sau MVP |
| D10 | Model AI | Cấu hình qua `AI_PROVIDER`/`AI_MODEL`; kiểm tra model còn được cung cấp trước Sprint 2 |
| D11 | Rate limit | 20 câu hỏi/giờ/người dùng; 5 lần đăng nhập sai/phút/IP |
| D12 | Trường mã hoá AES-256 | `email`, `parent_email`, `date_of_birth`, `content_text`, `image_url` |
| D13 | Hosting & deploy | 1 VPS/máy demo chạy Docker Compose + Caddy; Member D phụ trách |
| D14 | XP và level | Hỏi câu 10 XP; xem lại đáp án 5 XP; hoàn thành quiz 20 XP; level n cần 100×n XP tích luỹ |
| D15 | Leaderboard | Chỉ GLOBAL trong MVP |
| D16 | Ngôn ngữ | UI tiếng Việt (có `strings.xml` en dự phòng); AI trả lời theo ngôn ngữ của câu hỏi |
| D17 | Thời gian ôn tập | FE gửi `POST /api/answers/{id}/review-time` `{seconds}` khi rời màn hình đáp án |
| D18 | Approval | `develop` 1 approval, `main` 2 approvals, người tạo PR không tự approve |
| D19 | CI | GitHub Actions (`.github/workflows/ci.yml`) |
| D20 | Tên trên leaderboard | `displayName` do người dùng đặt khi đăng ký, không dùng email |

Muốn đổi một quyết định: tạo PR sửa bảng này và các mục liên quan (theo Mục 12).
