## Mô tả
<!-- Thay đổi gì và tại sao? -->

## Story / Ticket
- User story: US-xx
- Jira: 4CLNL-xx
- Phạm vi: [ ] Android  [ ] Backend  [ ] Docs/API  [ ] Hạ tầng/CI

## Thay đổi API / Schema
- [ ] Không đổi API hoặc schema
- [ ] Có đổi API → đã cập nhật `docs/api/openapi.yaml` (cần cả FE và BE approve)
- [ ] Có đổi schema DB → đã thêm file migration Flyway và cập nhật ERD
- [ ] Đây là thay đổi phá vỡ (đổi tên/xoá/đổi kiểu field) và đã báo cả nhóm

## Kiểm thử
- [ ] Đã chạy test local (unit test)
- [ ] Đã thử với staging hoặc mock theo contract
- [ ] Đã thêm/cập nhật test cho logic mới

## Ảnh chụp màn hình (PR của Android)
<!-- Dán ảnh hoặc video ngắn -->

## Checklist trước khi xin review
- [ ] Tuân thủ `docs/FE_BE_COMMON_RULES.md`
- [ ] Không có secret (API key, mật khẩu, JWT secret, service account) trong code
- [ ] Không còn code debug hoặc `TODO` quan trọng bỏ lửng
- [ ] Đã rebase/merge `develop` mới nhất và CI xanh
- [ ] Tên nhánh và commit đúng quy ước (`feat(US-xx): ...`)
